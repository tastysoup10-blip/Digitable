import"./BX2GU7Uw.js";import{s as t,r as p}from"./BCaXwhFt.js";import{I as c}from"./ciyfsgrx.js";function m(o,e){let r=p(e,["$$slots","$$events","$$legacy"]);const s=[["path",{d:"M20 6 9 17l-5-5"}]];c(o,t({name:"check"},()=>r,{get iconNode(){return s}}))}export{m as C};
//# sourceMappingURL=Rzw-TCWq.js.map
